﻿using System;
using System.Collections.Generic;
using OnlineRadioDatabase.Exceptions;

namespace OnlineRadioDatabase
{
    class OnlineRadioDatabase
    {
        static void Main(string[] args)
        {
            List<Song> songs = new List<Song>();
            int numberOfSongs = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberOfSongs; i++)
            {
                string[] songInfo = Console.ReadLine().Split(';');
                string artistName = songInfo[0];
                string songName = songInfo[1];
                try
                {
                    int minutes = int.Parse(songInfo[2].Split(':')[0]);
                    int seconds = int.Parse(songInfo[2].Split(':')[1]);
                    Song song = new Song(artistName, songName, minutes, seconds);
                    songs.Add(song);
                    Console.WriteLine("Song added.");
                }
                catch (InvalidSongException ise)
                {
                    Console.WriteLine(ise.Message);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid song length.");
                }    
            }
            Console.WriteLine($"Songs added: {songs.Count}");
            int totalDuration = 0;
            foreach (var song in songs)
            {
                totalDuration += song.Minutes * 60 + song.Seconds;
            }
            int totalMinutes = totalDuration/60;
            int totalSeconds = totalDuration%60;
            int totalHours = totalMinutes/60;
            totalMinutes %= 60;

            Console.WriteLine($"Playlist length: {totalHours}h {totalMinutes}m {totalSeconds}s");
        }
    }
}